DOMPDF manual package for cPanel (Composer-free)

Package contents
- lib/dompdf/: Dompdf 3.1.6 and its pinned runtime dependencies.
- No Composer autoloader is required; the application registers the required PSR-4 loaders itself.

Installation with cPanel File Manager
1. Upload dompdf-cpanel.zip to the application repository root: the directory that contains app/, public/, and lib/ (not public/).
2. In File Manager, select the ZIP and choose Extract. Keep the archive paths so the result is <application-root>/lib/dompdf/...
3. Confirm that these files exist:
   lib/dompdf/src/Dompdf.php
   lib/dompdf/src/Options.php
   lib/dompdf/vendor/dompdf/php-font-lib/src/FontLib/Font.php
4. Ensure PHP can read the extracted files. Typical permissions are 0755 for directories and 0644 for files. Do not make the files world-writable.
5. In cPanel MultiPHP Manager / Select PHP Version, use PHP 8.1+ and enable dom, mbstring, iconv, and fileinfo. The application also needs its normal PDO MySQL extensions.
6. Ensure the application's private storage/dompdf directory is writable by the PHP handler; storage must remain outside the public web root.
7. Log in as an authorized HR/Admin user and test a PDF export. The application loads Dompdf from lib/dompdf automatically.

Do not upload this package into public/, and do not run Composer on cPanel. If lib/dompdf already exists, back it up before extracting this package; extracting may overwrite files.

Included versions: dompdf 3.1.6, php-font-lib 1.0.2, php-svg-lib 1.0.2, masterminds/html5 2.11.0, sabberworm/php-css-parser 9.5.0. Upstream license texts are included in lib/dompdf/licenses/.
